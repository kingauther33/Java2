create view `products above average price` as
select `northwind`.`products`.`ProductName` AS `ProductName`, `northwind`.`products`.`UnitPrice` AS `UnitPrice`
from `northwind`.`products`
where `northwind`.`products`.`UnitPrice` > (select avg(`northwind`.`products`.`UnitPrice`) from `northwind`.`products`);

