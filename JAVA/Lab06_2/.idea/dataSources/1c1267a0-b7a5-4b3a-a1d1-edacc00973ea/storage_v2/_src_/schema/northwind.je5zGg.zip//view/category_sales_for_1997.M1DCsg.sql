create view `category sales for 1997` as
select `northwind`.`product sales for 1997`.`CategoryName`      AS `CategoryName`,
       sum(`northwind`.`product sales for 1997`.`ProductSales`) AS `CategorySales`
from `northwind`.`product sales for 1997`
group by `northwind`.`product sales for 1997`.`CategoryName`;

