create definer = root@localhost trigger books_update_qty1
    before update
    on books
    for each row
begin
        if (NEW.status = 3 OR NEW.status = 2) then
            set new.qty = 0;
        end if;
    end;

