create view `products by category` as
select `northwind`.`categories`.`CategoryName`  AS `CategoryName`,
       `northwind`.`products`.`ProductName`     AS `ProductName`,
       `northwind`.`products`.`QuantityPerUnit` AS `QuantityPerUnit`,
       `northwind`.`products`.`UnitsInStock`    AS `UnitsInStock`,
       `northwind`.`products`.`Discontinued`    AS `Discontinued`
from (`northwind`.`categories`
         join `northwind`.`products` on (`northwind`.`categories`.`CategoryID` = `northwind`.`products`.`CategoryID`))
where `northwind`.`products`.`Discontinued` <> 1;

