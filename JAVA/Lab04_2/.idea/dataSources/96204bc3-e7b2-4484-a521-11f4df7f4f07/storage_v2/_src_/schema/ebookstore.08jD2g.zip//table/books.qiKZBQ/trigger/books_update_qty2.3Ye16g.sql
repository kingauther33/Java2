create definer = root@localhost trigger books_update_qty2
    before insert
    on books
    for each row
begin
        if (NEW.status = 3 OR NEW.status = 2) then
            set NEW.qty = 0;
        end if;
    end;

