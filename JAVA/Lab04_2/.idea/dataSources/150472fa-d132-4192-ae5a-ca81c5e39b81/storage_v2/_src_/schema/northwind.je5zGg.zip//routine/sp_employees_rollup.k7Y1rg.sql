create
    definer = root@localhost procedure sp_employees_rollup()
BEGIN
SELECT Distinct City ,Sum(Salary) Salary_By_City FROM employees
GROUP BY City WITH ROLLUP;

END;

