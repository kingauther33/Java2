create definer = root@localhost view `customer and suppliers by city` as
select `northwind`.`customers`.`City`        AS `City`,
       `northwind`.`customers`.`CompanyName` AS `CompanyName`,
       `northwind`.`customers`.`ContactName` AS `ContactName`,
       'Customers'                           AS `Relationship`
from `northwind`.`customers`
union
select `northwind`.`suppliers`.`City`        AS `City`,
       `northwind`.`suppliers`.`CompanyName` AS `CompanyName`,
       `northwind`.`suppliers`.`ContactName` AS `ContactName`,
       'Suppliers'                           AS `Suppliers`
from `northwind`.`suppliers`
order by `City`, `CompanyName`;

